import boto3

def handler(event,context):
    print("Lambda execution successful")